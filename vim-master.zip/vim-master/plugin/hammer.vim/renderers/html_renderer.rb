command Hammer::ENV.browser, /html|xhtml/
